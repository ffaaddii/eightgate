import type { SessionUser } from '../auth/types.js'

declare global {
  namespace Express {
    interface Request {
      user?: SessionUser
    }
  }
}

export {}

