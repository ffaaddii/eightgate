/**
 * local server entry file, for local development
 */
import app from './app.js';
/**
 * start server with port
 */
const PORT = parseInt(process.env.PORT || '3001', 10);
const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server ready on port ${PORT}`);
});
/**
 * close server
 */
process.on('SIGTERM', () => {
    console.log('SIGTERM signal received');
    server.close(() => {
        console.log('Server closed');
        process.exit(0);
    });
});
process.on('SIGINT', () => {
    console.log('SIGINT signal received');
    server.close(() => {
        console.log('Server closed');
        process.exit(0);
    });
});
export default app;
